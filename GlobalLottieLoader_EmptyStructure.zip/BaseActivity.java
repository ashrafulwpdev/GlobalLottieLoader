
/**
 * GlobalLottieLoader - A reusable Lottie Loader utility for Android apps.
 * Developed by Softourtech (https://github.com/softourtech)
 * License: MIT
 */

package com.softourtech.globallottieloader;

import android.content.res.Resources;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;

import androidx.appcompat.app.AppCompatActivity;

import com.airbnb.lottie.LottieAnimationView;
import com.airbnb.lottie.LottieDrawable;
import com.airbnb.lottie.LottieProperty;
import com.airbnb.lottie.model.KeyPath;
import com.airbnb.lottie.value.LottieValueCallback;

import java.io.IOException;

public class BaseActivity extends AppCompatActivity {

    private FrameLayout loaderOverlay;
    private LottieAnimationView loaderAnimation;
    private int currentAnimationRes = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    public int dpToPx(int dp) {
        Resources res = getResources();
        return (res != null) ? (int) (dp * res.getDisplayMetrics().density) : dp;
    }

    public boolean isValidResource(int resId) {
        try {
            Resources res = getResources();
            if (res != null) {
                res.openRawResource(resId).close();
                return true;
            }
        } catch (Resources.NotFoundException | IOException e) {}
        return false;
    }

    /**
     * ✅ Show Global Lottie Loader with customization options
     */
    public void showGlobalLoader(int animationResId, int width, int height, boolean useRoundedBox,
                                 int overlayColor, boolean changeJsonColor, int jsonColor) {
        try {
            if (loaderOverlay == null) {
                loaderOverlay = new FrameLayout(this);
                loaderOverlay.setClickable(true);
                loaderOverlay.setFocusable(true);
                loaderOverlay.setOnTouchListener((v, event) -> true); // Block touch

                FrameLayout animationContainer = new FrameLayout(this);
                if (useRoundedBox) {
                    animationContainer.setBackgroundResource(android.R.drawable.dialog_holo_light_frame);
                    animationContainer.setPadding(dpToPx(16), dpToPx(16), dpToPx(16), dpToPx(16));
                }

                loaderAnimation = new LottieAnimationView(this);

                // Validate animation resource
                if (isValidResource(animationResId)) {
                    loaderAnimation.setAnimation(animationResId);
                    currentAnimationRes = animationResId;
                } else {
                    Log.e("BaseActivity", "Loader missing. Loading fallback.");
                    loaderAnimation.setAnimation(android.R.drawable.ic_popup_sync);
                    currentAnimationRes = android.R.drawable.ic_popup_sync;
                }

                loaderAnimation.setRepeatCount(LottieDrawable.INFINITE);
                loaderAnimation.playAnimation();
                loaderAnimation.setScaleX(1.0f);
                loaderAnimation.setScaleY(1.0f);

                // Optional: Apply color filter
                if (changeJsonColor) {
                    loaderAnimation.addValueCallback(
                            new KeyPath("**"),
                            LottieProperty.COLOR,
                            new LottieValueCallback<>(jsonColor)
                    );
                }

                // Set Lottie size
                FrameLayout.LayoutParams animParams = new FrameLayout.LayoutParams(width, height);
                animParams.gravity = Gravity.CENTER;
                animationContainer.addView(loaderAnimation, animParams);

                // Dynamic background
                int backgroundWidth = useRoundedBox ? width + dpToPx(32) : ViewGroup.LayoutParams.WRAP_CONTENT;
                int backgroundHeight = useRoundedBox ? height + dpToPx(32) : ViewGroup.LayoutParams.WRAP_CONTENT;

                FrameLayout.LayoutParams containerParams = new FrameLayout.LayoutParams(backgroundWidth, backgroundHeight);
                containerParams.gravity = Gravity.CENTER;
                loaderOverlay.addView(animationContainer, containerParams);

                ViewGroup rootView = findViewById(android.R.id.content);
                if (rootView != null) {
                    rootView.addView(loaderOverlay);
                }

                loaderOverlay.setBackgroundColor(overlayColor);
                loaderOverlay.setAlpha(0f);
                loaderOverlay.animate().alpha(1f).setDuration(250).start();

            } else {
                loaderOverlay.setBackgroundColor(overlayColor);
                loaderOverlay.setVisibility(View.VISIBLE);

                if (animationResId != currentAnimationRes && isValidResource(animationResId)) {
                    loaderAnimation.setAnimation(animationResId);
                    currentAnimationRes = animationResId;
                }

                if (changeJsonColor) {
                    loaderAnimation.addValueCallback(
                            new KeyPath("**"),
                            LottieProperty.COLOR,
                            new LottieValueCallback<>(jsonColor)
                    );
                }

                if (!loaderAnimation.isAnimating()) {
                    loaderAnimation.playAnimation();
                }

                loaderOverlay.animate().alpha(1f).setDuration(250).start();
            }
        } catch (Exception e) {
            Log.e("BaseActivity", "Loader error: " + e.getMessage());
            hideGlobalLoader();
        }
    }

    public void hideGlobalLoader() {
        if (loaderOverlay != null) {
            loaderOverlay.animate().alpha(0f).setDuration(250).withEndAction(() -> {
                loaderOverlay.setVisibility(View.GONE);
                if (loaderAnimation != null) {
                    loaderAnimation.pauseAnimation();
                }
            }).start();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (loaderAnimation != null) {
            loaderAnimation.cancelAnimation();
            loaderAnimation = null;
        }
        if (loaderOverlay != null) {
            ViewGroup rootView = findViewById(android.R.id.content);
            if (rootView != null) {
                rootView.removeView(loaderOverlay);
            }
            loaderOverlay = null;
        }
    }
}
